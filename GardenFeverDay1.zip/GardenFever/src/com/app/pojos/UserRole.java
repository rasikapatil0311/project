package com.app.pojos;

public enum UserRole {
CUSTOMER,ORDERTEAM
}
