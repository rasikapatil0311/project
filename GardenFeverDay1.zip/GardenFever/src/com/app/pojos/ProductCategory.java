package com.app.pojos;

public enum ProductCategory {
	TOOL,PLANT,FERTILIZER
}
